import { Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AccountComponent } from './account/account.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ChatroomComponent } from './chatroom/chatroom.component';
import { ChannelComponent } from './channel/channel.component';
import { ReportComponent } from './report/report.component';
import { UsersComponent } from './users/users.component';

export const routes: Routes = [
    {path:'login',component:LoginComponent},
    {path:'account',component:AccountComponent},
    {path:'signup',component:SignUpComponent},
    {path:'chatroom',component:ChatroomComponent},
    {path: 'channel/:channelName', component: ChannelComponent},
    {path: 'report',component:ReportComponent},
    {path: 'view-users',component:UsersComponent}
];
