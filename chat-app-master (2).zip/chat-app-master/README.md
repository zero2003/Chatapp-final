
# Chat-App

## Table of Contents

1. [Introduction](#introduction)
2. [Git Repository Organization](#git-repository-organization)
3. [Data Structures](#data-structures)
   - [Client-Side](#client-side)
   - [Server-Side](#server-side)
4. [Angular Architecture](#angular-architecture)
5. [Node Server Architecture](#node-server-architecture)
6. [Server-Side Routes](#server-side-routes)
7. [Client-Server Interaction](#client-server-interaction)

---

## Introduction

This project is a web application developed using Angular on the frontend and Node.js with Express on the backend. It includes user management, group management, channel management, and user roles with various interactions between the client and server.

## Git Repository Organization

### Branching Strategy

- **Main Branch**: The main branch is the stable version of the application, containing fully tested and reviewed code.
- **Feature Branches**: Each new feature or bug fix was developed in a separate branch (e.g., `version-2`, `version-1`). These branches were created from the main branch and merged back into it after completing development and testing.
- **Update Frequency**: Code was regularly committed to feature branches with detailed commit messages. Once a feature was complete, it was merged into the main branch through a pull request, ensuring code reviews and testing before integration.

### Server/Frontend Organization

- The repository is divided into two main directories: `client/` for Angular code and `server/` for Node.js code. This separation ensures a clean structure and easier management.

## Data Structures

### Client-Side

- **User**:
  ```typescript
  interface User {
    id: number;
    username: string;
    roles: string[]; // e.g., ['user', 'group administrator']
    groups: number[]; // Array of group IDs the user is part of
  }
  ```

- **Group**:
  ```typescript
  interface Group {
    id: number;
    name: string;
    administrators: number[]; // Array of user IDs who are admins
    channels: string[]; // List of channel names
    bannedUsers: { [channelName: string]: number[] }; // Map of banned user IDs per channel
  }
  ```

### Server-Side

- **User Model**:
  ```javascript
  const userSchema = new mongoose.Schema({
    id: Number,
    username: String,
    roles: [String], // ['user', 'group administrator']
    groups: [Number] // Array of group IDs
  });
  ```

- **Group Model**:
  ```javascript
  const groupSchema = new mongoose.Schema({
    id: Number,
    name: String,
    administrators: [Number], // User IDs
    channels: [String], // Channel names
    bannedUsers: { type: Map, of: [Number] } // Channel name to array of banned user IDs
  });
  ```

- **Channel**: Channels are stored as strings within the Group schema and do not have a separate schema in the backend.

## Angular Architecture

### Components

- **Login Component**: Displays a form that allows users to login.
- **Sign-up Component**: Displays a form that allows new users to sign up.
- **User Management Component**: Displays a list of users with options to promote them to Group Admin or Super Admin.
- **Group Management Component**: Allows admins to create, manage groups, and channels.
- **Channel Component**: Displays the channel content and manages user interactions.

### Services

- **UserService**: Handles API calls related to user management.
- **GroupService**: Manages API calls for group and channel operations.
- **AuthService**: Handles authentication and role management.

### Models

- **User**: Defines the structure of the user object across components.
- **Group**: Defines the group and associated channels.

### Routes

Angular routes are defined to navigate between user management, group management, and specific channels.

## Node Server Architecture

### Modules

- **Express.js**: Used for routing and handling HTTP requests.
- **Mongoose**: Used for MongoDB data modeling.
- **Body-Parser**: Middleware to parse incoming request bodies.

### Functions

- **User Management**: Functions to create users, assign roles, and fetch user details.
- **Group Management**: Functions to create groups, assign administrators, and manage channels.
- **Authentication**: Middleware to verify user roles and permissions.

### Files

- **server.js**: The main entry point of the server application.

### Global Variables

- **users**: Stores all user data in memory (or database).
- **groups**: Stores all group data, including channels and banned users.

## Server-Side Routes

### User Routes

- **Get All Users**
  - **Endpoint**: `GET /api/users`
  - **Description**: Retrieves a list of all users.
  - **Response**: JSON array of user objects.

- **Delete User**
  - **Endpoint**: `DELETE /api/users/:userId`
  - **Description**: Deletes a user by their ID.
  - **Parameters**: `userId` (in URL path)
  - **Response**: JSON message indicating success and the deleted user object.

- **Promote Group Admin**
  - **Endpoint**: `POST /api/users/:userId/promote-group-admin`
  - **Description**: Promotes a user to a group administrator for a specific group.
  - **Parameters**: `userId` (in URL path), `groupId` (in request body)
  - **Response**: JSON message indicating success and the updated group object.

- **Promote Super Admin**
  - **Endpoint**: `POST /api/users/:userId/promote-super-admin`
  - **Description**: Promotes a user to a super administrator.
  - **Parameters**: `userId` (in URL path)
  - **Response**: JSON message indicating success.

### Group Routes

- **Get All Groups**
  - **Endpoint**: `GET /api/groups`
  - **Description**: Retrieves a list of all groups.
  - **Response**: JSON array of group objects.

- **Get All Group Join Requests**
  - **Endpoint**: `GET /api/groupjoinrequests`
  - **Description**: Retrieves all pending requests to join groups.
  - **Response**: JSON array of join request objects.

- **Request to Join Group**
  - **Endpoint**: `POST /api/request-join`
  - **Description**: Allows a user to request to join a group.
  - **Parameters**: `userId`, `groupId` (in request body)
  - **Response**: JSON message indicating the request status.

- **Respond to Group Join Request**
  - **Endpoint**: `POST /api/respond-request`
  - **Description**: Allows an administrator to accept or reject a user's request to join a group.
  - **Parameters**: `userId`, `groupId`, `action` (in request body)
  - **Response**: JSON message indicating the request has been accepted or rejected.

- **Create Group**
  - **Endpoint**: `POST /api/groups`
  - **Description**: Creates a new group.
  - **Parameters**: `groupName`, `userId` (in request body)
  - **Response**: JSON object representing the newly created group.

- **Delete Group**
  - **Endpoint**: `DELETE /api/groups/:groupId`
  - **Description**: Deletes a group by its ID.
  - **Parameters**: `groupId` (in URL path)
  - **Response**: JSON message indicating success.

- **Create Channel**
  - **Endpoint**: `POST /api/groups/:groupId/channels`
  - **Description**: Adds a new channel to a specific group.
  - **Parameters**: `groupId` (in URL path), `channelName` (in request body)
  - **Response**: JSON message and updated list of channels.

- **Remove Channel**
  - **Endpoint**: `DELETE /api/groups/:groupId/channels/:channelName`
  - **Description**: Removes a channel from a specific group.
  - **Parameters**: `groupId`, `channelName` (in URL path)
  - **Response**: JSON message and updated list of channels.

- **Remove User from Group**
  - **Endpoint**: `POST /api/groups/:groupId/remove-user`
  - **Description**: Removes a user from a specific group.
  - **Parameters**: `groupId` (in URL path), `targetUserId` (in request body)
  - **Response**: JSON message and updated list of the user's groups.

- **Leave Group**
  - **Endpoint**: `POST /api/leave-group`
  - **Description**: Allows a user to leave a group they are part of.
  - **Parameters**: `userId`, `groupId` (in request body)
  - **Response**: JSON message indicating success.

- **Ban User from Channel**
  - **Endpoint**: `POST /api/groups/:groupId/ban-user`
  - **Description**: Bans a user from a specific channel within a group.
  - **Parameters**: `groupId` (in URL path), `channelName`, `userId` (in request body)
  - **Response**: JSON message indicating success.

### Authentication Routes

- **Sign Up**
  - **Endpoint**: `POST /api/signup`
  - **Description**: Registers a new user.
  - **Parameters**: `username`, `email`, `password` (in request body)
  - **Response**: JSON object representing the newly created user (without password).

- **Login**
  - **Endpoint**: `POST /api/auth`
  - **Description**: Authenticates a user.
  - **Parameters**: `email`, `password` (in request body)
  - **Response**: JSON object with user details (excluding password) and validation status.


## Client-Server Interaction

### User Promotion

- **Client**: 
  - The User Management Component provides options to promote a user to a Group Admin or Super Admin. When the promotion is initiated by an admin, the client sends an HTTP POST request to the appropriate server endpoint (`/api/users/:userId/promote-group-admin` or `/api/users/:userId/promote-super-admin`).
  - The request includes the user's ID and, if applicable, the group ID in the request body.
  
- **Server**:
  - The server processes the request by updating the user's roles and, in the case of group admin promotion, adds the user to the group's administrator list. 
  - The server then returns the updated user object, or an error message if the operation fails (e.g., if the user or group is not found).

- **Client Update**:
  - Upon receiving the updated user object, the client refreshes the user list in the User Management Component to reflect the changes. The UI may show a success message or update the user's role display accordingly.

### Group and Channel Management

- **Client**:
  - The Group Management Component allows admins to create and manage groups and channels. Actions such as creating a group, adding a channel, or removing a channel trigger corresponding API calls via the `GroupService`.
  - For example, creating a new group involves sending an HTTP POST request to `/api/groups` with the group name and admin user ID in the request body.
  
- **Server**:
  - The server processes these requests by updating the relevant data structures (e.g., adding a new group to the `groups` array, updating a group's channels).
  - The server returns the updated group object or an appropriate success/error message.

- **Client Update**:
  - The UI components are designed to automatically update based on the server's response. Angular’s reactive forms and services ensure that changes are reflected immediately in the client interface.
  - For example, after a new channel is added, the channel list in the Group Management Component will be updated without requiring a page reload.

### User Authentication and Session Management

- **Client**:
  - The Login Component handles user authentication. When a user submits their credentials, an HTTP POST request is sent to the `/api/auth` endpoint with the user's email and password.
  - If the login is successful, the client may store the user session (e.g., JWT token) locally for subsequent authenticated requests.

- **Server**:
  - The server verifies the credentials against stored user data. If the credentials are valid, the server responds with the user details (excluding the password) and a success message.
  - The server might also issue a JWT token or session ID for maintaining user sessions.

- **Client Update**:
  - Upon successful login, the client may redirect the user to the main chat interface or a dashboard. The stored session token is used for authorizing further API requests.

### Group Join Requests

- **Client**:
  - Users can request to join a group through the Group Management Component. An HTTP POST request is sent to the `/api/request-join` endpoint with the user ID and group ID.
  - Administrators can then view and respond to these requests through the same component.

- **Server**:
  - The server processes these join requests by adding them to a list of pending requests and returns a confirmation message.
  - When an administrator responds to a join request (either accepting or rejecting it), the server updates the user's group membership and removes the request from the pending list.

- **Client Update**:
  - After a user submits a join request, the client updates the UI to reflect the pending status. Upon receiving the admin's response, the user's group list is updated to show their new memberships, if accepted.


## REST API Design

The server exposes a set of RESTful API endpoints for the client to interact with. Each endpoint allows performing standard CRUD (Create, Read, Update, Delete) operations on resources like users, groups, and channels.

### Key API Endpoints

- **Users**: Provides endpoints for user registration, authentication, and role management.
- **Groups**: Handles the creation of groups, managing group membership, channels, and group-related operations.
- **Channels**: Facilitates operations related to creating, deleting, and managing communication channels within groups.
- **Authentication**: Manages user login and session handling.

Each route is tied to specific HTTP methods:

- **GET**: Retrieve resources.
- **POST**: Create new resources.
- **DELETE**: Remove resources.

---

## MongoDB Implementation

### MongoDB Overview

MongoDB, a NoSQL database, is used for persistent data storage. Data is stored as documents within collections. MongoDB is integrated with the Node.js backend using the native MongoDB driver.

### MongoDB Client for Integration

The native MongoDB client is used to define collections and interact with the database for CRUD operations.

### Key Collections

- **Users**: Stores user details like username, email, password, roles, and group memberships.
- **Groups**: Stores group data, including administrators, available channels, and banned users.

---

## Server-Side Routes

### User Routes

- **Create User (Signup)**:
  - **Endpoint**: `POST /api/signup`
  - **Description**: Registers a new user and stores the information in MongoDB.
  - **Example**:
  ```javascript
  app.post('/api/signup', async (req, res) => {
    const { username, email, password, profileImage } = req.body;
    const hashedPassword = bcrypt.hashSync(password, 10);
    const user = { username, email, password: hashedPassword, profileImage };
    await usersCollection.insertOne(user);
    res.json(user);
  });
  ```

- **Get All Users**:
  - **Endpoint**: `GET /api/users`
  - **Description**: Fetches all registered users from MongoDB.
  - **Example**:
  ```javascript
  app.get('/api/users', async (req, res) => {
    const users = await usersCollection.find().toArray();
    res.json(users);
  });
  ```

### Group Routes

- **Create Group**:
  - **Endpoint**: `POST /api/groups`
  - **Description**: Creates a new group and stores it in MongoDB.
  - **Example**:
  ```javascript
  app.post('/api/groups', async (req, res) => {
    const { groupName, userId } = req.body;
    const group = { name: groupName, administrators: [userId], channels: [] };
    await groupsCollection.insertOne(group);
    res.json(group);
  });
  ```

- **Ban User from Channel**:
  - **Endpoint**: `POST /api/groups/:groupId/ban-user`
  - **Description**: Bans a user from a specific channel.
  - **Example**:
  ```javascript
  app.post('/api/groups/:groupId/ban-user', async (req, res) => {
    const { groupId } = req.params;
    const { channelName, userId } = req.body;
    const group = await groupsCollection.findOne({ id: groupId });
    if (!group.bannedUsers[channelName]) {
      group.bannedUsers[channelName] = [];
    }
    group.bannedUsers[channelName].push(userId);
    await groupsCollection.updateOne({ id: groupId }, { $set: { bannedUsers: group.bannedUsers } });
    res.json({ message: `User ${userId} banned from channel ${channelName}` });
  });
  ```

---

## Client-Server Interaction with MongoDB

The client interacts with the server via API calls. These API calls, in turn, interact with MongoDB to store, update, or retrieve data.

### Signup Process:

- **Client**: Sends a POST request to `/api/signup` with the user details.
- **Server**: Creates a new user document in MongoDB using the MongoDB client.
- **Database**: MongoDB stores the user’s information in the `users` collection.

### Group Management:

- **Client**: Sends a POST request to `/api/groups` to create a new group.
- **Server**: Creates a new group document in MongoDB and adds the user as the group administrator.
- **Database**: MongoDB stores the group’s information in the `groups` collection.

### Channel Creation:

- **Client**: Sends a POST request to `/api/groups/:groupId/channels` to add a new channel.
- **Server**: Updates the group’s `channels` field in the MongoDB document.
- **Database**: MongoDB stores the updated list of channels in the `groups` collection.

### User Interaction in Channel:

- **Client**: Users send and receive messages in channels.
- **Server**: Handles real-time communication using WebSockets (e.g., Socket.IO) for sending and receiving messages.
- **Database**: MongoDB is used to store chat history, user roles, and other metadata.
