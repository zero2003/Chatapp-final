// update.js
async function updateUser(usersCollection, userId, updates) {
    const result = await usersCollection.updateOne(
      { id: userId },
      { $set: updates }
    );
  
    if (result.matchedCount === 0) {
      throw new Error('User not found');
    }
  
    return result;
  }
  
  module.exports = updateUser;
  