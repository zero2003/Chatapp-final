describe('E2E Test Flow: Signup -> Chatroom -> Request -> Login -> Chatroom', () => {

    it('should login, navigate to chatroom, and put in a request', () => {
    
      cy.visit('http://localhost:4200/login');
      // Step 1: Navigate to signup
      cy.get('a.nav-link[routerLink="/signup"]').click();
      cy.url().should('include', '/signup');
      cy.contains('Sign Up').should('be.visible');  // Ensure Chatroom page is visible

  
      // Step 2: Fill up details and submit
      cy.get('input[name="username"]').type('finn');
      cy.get('input[name="email"]').type('finn@example.com');  // Fill in username
      cy.get('input[name="password"]').type('123');  // Fill in password
      cy.get('.avatar-options img').eq(1).click();  // Select the first avatar image
      cy.get('button[type="submit"]').click();  // Click the login button
  
      // Step 3: Navigate to the Chatroom
      cy.get('a.nav-link[routerLink="/chatroom"]').click();
      cy.url().should('include', '/chatroom');  // Assert we are on the chatroom page
      cy.contains('Chatroom').should('be.visible');  // Ensure Chatroom page is visible
    
      // Step 4: Submit a join request and logout
      cy.get('button.request-btn').first().click();
      cy.contains('a.nav-link', 'Logout').click();

      // Step 5: Login
      cy.visit('http://localhost:4200/login');  // Visit the login page
      cy.get('input[name="email"]').type('super@example.com');  // Fill in username
      cy.get('input[name="password"]').type('123');  // Fill in password
      cy.get('button[type="submit"]').click();  // Click the login button

      // Step 6: Navigate to the Chatroom, Accept Request, and Logout
      cy.get('a.nav-link[routerLink="/chatroom"]').click();
      cy.url().should('include', '/chatroom');  // Assert we are on the chatroom page
      cy.contains('Chatroom').should('be.visible');  // Ensure Chatroom page is visible
      cy.contains('span', 'finn') // Find the span with the username "Finn"
        .parent() // Traverse to the parent element (join-request-box)
        .find('button.btn-success') // Find the "Accept" button
        .click(); // Click the "Accept" button
      cy.contains('a.nav-link', 'Logout').click();

      // Step 7: Login and go to chatroom
      cy.visit('http://localhost:4200/login');  // Visit the login page
      cy.get('input[name="email"]').type('finn@example.com');  // Fill in username
      cy.get('input[name="password"]').type('123');  // Fill in password
      cy.get('button[type="submit"]').click();  // Click the login button
      cy.get('a.nav-link[routerLink="/chatroom"]').click();

      // Step 8: Delete account
      cy.get('a.nav-link[routerLink="/account"]').click();
      cy.contains('Account Details').should('be.visible');
      cy.get('button.btn.btn-danger').click();  // Clicks the button with the class 'btn btn-danger'

      cy.contains('Login').should('be.visible');
    });
  
  });