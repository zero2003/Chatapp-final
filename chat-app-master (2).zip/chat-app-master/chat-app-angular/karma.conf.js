module.exports = function (config) {
    config.set({
      basePath: '',
      frameworks: ['jasmine', '@angular-devkit/build-angular'],
      plugins: [
        require('karma-jasmine'),
        require('karma-chrome-launcher'),
        require('karma-jasmine-html-reporter'),
        require('karma-coverage'),
        require('@angular-devkit/build-angular/plugins/karma')
      ],
      client: {
        clearContext: false, // leave Jasmine Spec Runner output visible in browser
        jasmine: {
          // Enable full stack trace
          fullStackTrace: true,
        },
      },
      coverageReporter: {
        dir: require('path').join(__dirname, './coverage/chat-app-angular'),
        subdir: '.',
        reporters: [{ type: 'html' }, { type: 'text-summary' }]
      },
      reporters: ['progress', 'kjhtml'],
      port: 9876,
      colors: true,
      
      // Change log level to debug for detailed logging
      logLevel: config.LOG_DEBUG,
  
      // To enable verbose console logging from the browser
      browserConsoleLogOptions: {
        level: 'debug',  // Log everything from the browser
        format: '%b %T: %m', // Customize the format
        terminal: true,
      },
  
      autoWatch: true,
      browsers: ['Chrome'],
      singleRun: false,
      restartOnFileChange: true
    });
  };
  