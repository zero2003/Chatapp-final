import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgFor } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-account',
  standalone: true,
  imports: [NgFor],
  templateUrl: './account.component.html',
  styleUrl: './account.component.css'
})
export class AccountComponent {
  user: any = {};

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    const storedUser = sessionStorage.getItem('user');
    if (storedUser) {
      this.user = JSON.parse(storedUser);
    } else {
      this.router.navigate(['/login']);
    }
  }

  deleteUser(): void {
    if (confirm('Are you sure you want to delete your account? This action cannot be undone.')) {
      this.http.delete(`http://localhost:3000/api/users/${this.user.id}`).subscribe(response => {
        console.log('User deleted:', response);
        sessionStorage.removeItem('user');
        this.router.navigate(['/login']); // Redirect to login page after account deletion
      }, error => {
        console.error('Error:', error);
      });
    }
  }

}
