import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgIf, NgFor } from '@angular/common';
import { RouterModule } from '@angular/router';

interface Group {
  id: number;
  name: string;
  administrators: number[];
  channels: string[];
  bannedUsers: { [channelName: string]: number[] };
}

interface User {
  id: number;
  username: string;
  roles: string[];
  groups: number[]; // Array of group IDs the user belongs to
}

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [NgFor, NgIf, RouterModule],
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  users: User[] = [];
  groups: Group[] = []; // Add this if you need to access group details
  isLoading: boolean = false;

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchUsers();
    this.fetchGroups(); // Fetch groups if you need to manage group admins
  }

  fetchUsers() {
    this.isLoading = true;
    this.http.get<User[]>('http://localhost:3000/api/users')
      .subscribe(users => {
        this.users = users;
        this.isLoading = false;
      }, error => {
        console.error('Error fetching users:', error);
        this.isLoading = false;
      });
  }

  fetchGroups() {
    this.http.get<Group[]>('http://localhost:3000/api/groups')
      .subscribe(groups => {
        this.groups = groups;
      }, error => {
        console.error('Error fetching groups:', error);
      });
  }

  promoteToGroupAdmin(userId: number, groupId: number) {
    this.isLoading = true;
    this.http.post(`http://localhost:3000/api/users/${userId}/promote-group-admin`, { groupId })
      .subscribe(response => {
        console.log('User promoted to Group Admin:', response);
        this.updateUserRoles(userId, 'group administrator');
        this.http.get<Group[]>('http://localhost:3000/api/groups')
        .subscribe(groups => {
          this.groups = groups;
        }, error => {
          console.error('Error fetching groups:', error);
        });
      }, error => {
        console.error('Error promoting user to Group Admin:', error);
        this.isLoading = false;
      });
  }

  promoteToSuperAdmin(userId: number) {
    this.isLoading = true;
    this.http.post(`http://localhost:3000/api/users/${userId}/promote-super-admin`, {})
      .subscribe(response => {
        console.log('User promoted to Super Admin:', response);
        this.updateUserRoles(userId, 'super administrator');
        this.fetchUsers(); // Refresh the list of users
      }, error => {
        console.error('Error promoting user to Super Admin:', error);
        this.isLoading = false;
      });
  }

  // Helper method to update user roles locally after a promotion
  updateUserRoles(userId: number, newRole: string) {
    const user = this.users.find(u => u.id === userId);
    if (user && !user.roles.includes(newRole)) {
      user.roles.push(newRole);
    }
  }

  getGroupById(groupId: number): Group | undefined {
    return this.groups.find(group => group.id === groupId);
  }
  
}
