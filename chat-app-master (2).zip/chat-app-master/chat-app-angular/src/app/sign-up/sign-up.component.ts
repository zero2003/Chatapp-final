import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-sign-up',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './sign-up.component.html',
  styleUrl: './sign-up.component.css'
})
export class SignUpComponent implements OnInit {
  username: string = '';
  email: string = '';
  password: string = '';
  selectedAvatar: string = '';
  errorMessage: string = '';

  availableAvatars: string[] = ['gumball.jpg', 'anais.jpg', 'darwin.jpg'];

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    // Set default avatar if none selected
    this.selectedAvatar = this.availableAvatars[0];  // Default to the first avatar
  }

  onSignUp() {
    const newUser = {
      username: this.username,
      email: this.email,
      password: this.password,
      profileImage: this.selectedAvatar,
      roles: ['chat user'],  // Default role for new sign-ups
      groups: []
    };

    // Send the new user data to the server to store it
    this.http.post<any>('http://localhost:3000/api/signup', newUser).subscribe(
      response => {
        // If sign-up is successful, log in the user
        sessionStorage.setItem('user', JSON.stringify(response));
        this.router.navigate(['/account']);
      },
      error => {
        this.errorMessage = 'Username already exists.';
      }
    );
  }

  selectAvatar(avatar: string) {
    this.selectedAvatar = avatar;
  }
}
