// add.js
async function addUser(usersCollection, userData) {
  // Check if the username or email already exists
  const existingUser = await usersCollection.findOne({ $or: [{ username: userData.username }, { email: userData.email }] });
  if (existingUser) {
    throw new Error('Username or email already exists');
  }

  // Create the new user
  const newUser = {
    ...userData,
    id: Date.now(),
    roles: ['chat user'],  // Default role for new sign-ups
    groups: []
  };

  // Insert the new user into MongoDB
  await usersCollection.insertOne(newUser);

  // Return the new user without password
  const { password, ...userWithoutPassword } = newUser;
  return userWithoutPassword;
}

module.exports = addUser;
