async function removeGroup(groupsCollection, groupId) {
    const result = await groupsCollection.deleteOne({ id: groupId });
    if (result.deletedCount === 0) {
      throw new Error('Group not found');
    }
    return result;
  }
  
  module.exports = removeGroup;
  