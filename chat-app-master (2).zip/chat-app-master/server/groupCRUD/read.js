async function getAllGroups(groupsCollection) {
    const groups = await groupsCollection.find().toArray();
    return groups;
  }
  
  async function getGroupById(groupsCollection, groupId) {
    const group = await groupsCollection.findOne({ id: groupId });
    if (!group) {
      throw new Error('Group not found');
    }
    return group;
  }
  
  module.exports = { getAllGroups, getGroupById };
  