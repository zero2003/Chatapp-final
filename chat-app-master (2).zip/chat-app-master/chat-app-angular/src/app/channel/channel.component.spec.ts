import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ChannelComponent } from './channel.component'; // Assuming this is standalone
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing'; // Don't need HttpTestingController unless testing HTTP calls

describe('ChannelComponent', () => {
  let component: ChannelComponent;
  let fixture: ComponentFixture<ChannelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule, 
        HttpClientTestingModule, 
        ChannelComponent // Correctly importing the standalone component
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ChannelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  // Basic test to check component creation
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  afterEach(() => {
    fixture.destroy(); // Properly clean up the fixture after each test
    TestBed.resetTestingModule(); // Reset the testing environment after each test
  });
});
