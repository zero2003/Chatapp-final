describe('E2E Test Flow: Login -> Chatroom -> Channel', () => {

    it('should login, navigate to chatroom, and enter a channel', () => {
      // Step 1: Login
      cy.visit('http://localhost:4200/login');  // Visit the login page
      cy.get('input[name="email"]').type('super@example.com');  // Fill in username
      cy.get('input[name="password"]').type('123');  // Fill in password
      cy.get('button[type="submit"]').click();  // Click the login button
  
      // Step 2: Navigate to the Chatroom
      cy.get('a.nav-link[routerLink="/chatroom"]').click();
      cy.url().should('include', '/chatroom');  // Assert we are on the chatroom page
      cy.contains('Chatroom').should('be.visible');  // Ensure Chatroom page is visible
  
      // Step 3: Enter a Channel
      cy.contains('a', 'General Discussion').click();
  
      // Step 4: Perform actions inside the channel
      cy.get('input.form-control').type('Hello, everyone!');  // Type a message into the input
      cy.get('button.btn-primary').click();  // Click the Send button
      cy.contains('Hello, everyone!').should('be.visible');  // Assert the message appears in the chat
    });
  
  });
  