// remove.js
async function removeUser(usersCollection, userId) {
    const result = await usersCollection.deleteOne({ id: userId });
    if (result.deletedCount === 0) {
      throw new Error('User not found');
    }
    return result;
  }
  
  module.exports = removeUser;
  