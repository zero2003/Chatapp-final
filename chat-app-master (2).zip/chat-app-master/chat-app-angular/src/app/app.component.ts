import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgIf } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  standalone: true,
  imports: [NgIf, RouterModule],
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Chat App';

  constructor(private router: Router) {}

 
  isLoggedIn(): boolean {
    return sessionStorage.getItem('user') !== null;
  }


  onLogout() {

    sessionStorage.removeItem('user');
    this.router.navigate(['/login']);
  }
}
