async function addGroup(groupsCollection, usersCollection, groupData) {
    const { groupName, userId } = groupData;
  
    // Find the user to ensure they are a group administrator
    const user = await usersCollection.findOne({ id: userId });
    if (!user) {
      throw new Error('User not found');
    }

    const groupCount = await groupsCollection.countDocuments();
    const newGroupId = groupCount + 1;

    
    // Create the new group
    const newGroup = {
      id: newGroupId,
      name: groupName,
      administrators: [userId],
      channels: []  // Initial empty channels
    };
  
    // Insert the group into the MongoDB collection
    await groupsCollection.insertOne(newGroup);
  
    return newGroup;
  }
  
  module.exports = addGroup;
  