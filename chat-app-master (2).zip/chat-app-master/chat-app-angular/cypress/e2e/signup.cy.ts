describe('E2E Test Flow: SignUp -> Account -> Login', () => {

    it('should signup', () => {
      // Step 1: signup
      cy.visit('http://localhost:4200/login');  // Visit the login page
  
      // Step 2: Navigate to signup
      cy.get('a.nav-link[routerLink="/signup"]').click();
      cy.url().should('include', '/signup');
      cy.contains('Sign Up').should('be.visible');  // Ensure Chatroom page is visible

  
      // Step 3: Fill up details and submit
      cy.get('input[name="username"]').type('finn');
      cy.get('input[name="email"]').type('finn@example.com');  // Fill in username
      cy.get('input[name="password"]').type('123');  // Fill in password
      cy.get('.avatar-options img').eq(1).click();  // Select the first avatar image
      cy.get('button[type="submit"]').click();  // Click the login button

      cy.contains('Account Details').should('be.visible');
      cy.get('button.btn.btn-danger').click();  // Clicks the button with the class 'btn btn-danger'

      cy.contains('Login').should('be.visible');

    });
  
  });
  