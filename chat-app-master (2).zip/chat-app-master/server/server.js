var express = require('express');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
var app = express();
var http = require('http').Server(app);

app.use(cors());
app.use(express.static(__dirname + '/www'));
app.use(express.json());
app.use('/uploads', express.static('uploads'));


// Import socket functionality
const initSocket = require('./sockets');
initSocket(http);

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});
const upload = multer({ storage: storage });

const users = [
  {
    id: 1,
    username: 'super',
    email: 'super@example.com',
    password: '123',
    profileImage: 'gumball.jpg',
    roles: ['super administrator', 'group administrator'],
    groups: []
  },
  {
    id: 2,
    username: 'john_doe',
    email: 'john.doe@example.com',
    password: '123',
    profileImage: 'anais.jpg',
    roles: ['chat user'],
    groups: [1,3,4]
  },
  {
    id: 3,
    username: 'jane_smith',
    email: 'jane.smith@example.com',
    password: '123',
    profileImage: 'darwin.jpg',
    roles: ['group administrator'],
    groups: [4,5]
  }
];

  const groups = [
    { id: 1, name: 'general', administrators: [1], channels: ['General Discussion', 'Off-Topic'] },
    { id: 2, name: 'admins', administrators: [1], channels: ['Admin Announcements']},
    { id: 3, name: 'sports', administrators: [], channels: ['Football', 'Basketball']},
    { id: 4, name: 'music', administrators: [3], channels: ['Rock Music', 'Classical Music'], bannedUsers: {'Rock Music': [2]}},
    { id: 5, name: 'technology', administrators: [3], channels: ['Tech News', 'Programming'] }
  ];

let groupJoinRequests = [];


//MongoDB Connection
const { MongoClient } = require('mongodb');
const uri = "mongodb://localhost:27017";
const client = new MongoClient(uri);

let db, usersCollection, groupsCollection, groupJoinRequestsCollection;

async function connectDB() {
  try {
    await client.connect();
    db = client.db('chat-app');
    usersCollection = db.collection('users');
    groupsCollection = db.collection('groups');
    groupJoinRequestsCollection = db.collection('groupJoinRequests');
    console.log("Connected to MongoDB");

    // Initialize Users if not present
    const usersCount = await usersCollection.countDocuments();
    if (usersCount === 0) {
      await usersCollection.insertMany(users);
      console.log('Users initialized in MongoDB');
    }

    // Initialize Groups if not present
    const groupsCount = await groupsCollection.countDocuments();
    if (groupsCount === 0) {
      await groupsCollection.insertMany(groups);
      console.log('Groups initialized in MongoDB');
    }

    
  } catch (error) {
    console.error('Failed to connect to MongoDB:', error);
  }
}

connectDB();

//------------------------------------------------------------------------------------------------------------------------------//

/**************************************************************************
 *                                                                        *
 *                            U S E R   R O U T E S                       *
 *                                                                        *
 **************************************************************************/

const {getAllUsers, getUserById} = require('./userCRUD/read');
const addUser = require('./userCRUD/add');
const removeUser = require('./userCRUD/remove');
const updateUser = require('./userCRUD/update');


// Get all users
app.get('/api/users', async (req, res) => {
  try {
    const users = await getAllUsers(usersCollection);
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

app.post('/api/signup', async (req, res) => {
  const { username, email, password, profileImage } = req.body;

  if ( !username || !email || !password || !profileImage) {
    return res.status(400).json({ message: "All fields are required"});
  }

  try {
    const newUser = await addUser(usersCollection, { username, email, password, profileImage });

    // Send back the newly created user (without password) and success message
    res.json(newUser);

  } catch (error) {
    console.error('Sign-up error:', error.message);
    res.status(400).json({ message: error.message });
  }
});


// Delete User Route
app.delete('/api/users/:userId', async (req, res) => {

  const userId = parseInt(req.params.userId, 10);

  try {

    const result = await removeUser(usersCollection, userId);

    const groups = await groupsCollection.find().toArray();
    for (const group of groups) {
      const isAdmin = group.administrators.includes(userId);

      if (isAdmin) {
        await groupsCollection.updateOne(
          { id: group.id },
          { $pull: { administrators: userId } }
        );
      }
    }
    res.json({ message: 'User deleted successfully', result });

  } catch (error) {

    res.status(400).json({ message: error.message });

  }
});

  
  

// Login route
app.post('/api/auth', async (req, res) => {
    const { email, password } = req.body;
    console.log('Received email:', email);
    console.log('Received password:', password);

    try{

      const user = await usersCollection.findOne({ email: email, password: password });

      if (user) {
          const { password, ...userWithoutPassword } = user; // Exclude password from the response
          res.json({ ...userWithoutPassword, valid: true });
      } else {
          console.log('Authentication failed. Invalid credentials.');
          res.status(401).json({ message: 'Invalid credentials', valid: false });
      }
    } catch (error) {
      console.error('Error during authentication:', error);
      res.status(500).json({ message: 'Internal server error', valid: false })
    }
});

//----------------------------------------------------------------------------------------------------------//

/**************************************************************************
 *                                                                        *
 *                            G R O U P   R O U T E S                       *
 *                                                                        *
 **************************************************************************/

// Import group CRUD functions
const { getAllGroups, getGroupById } = require('./groupCRUD/read');
const addGroup = require('./groupCRUD/add');
const updateGroup = require('./groupCRUD/update');
const removeGroup = require('./groupCRUD/remove');


// Route to get all groups
app.get('/api/groups', async (req, res) => {
  try {
    const groups = await getAllGroups(groupsCollection);
    res.json(groups);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create group route
app.post('/api/groups', async (req, res) => {
  const { groupName, userId } = req.body;

  if ( !groupName) {
    return res.status(400).json({ message: "All fields are required"});
  }

  try {

    const newGroup = await addGroup(groupsCollection, usersCollection, { groupName, userId });

    await usersCollection.updateOne(
      { id: userId },
      { $push: { groups: newGroup.id } }
    );

    res.json(newGroup);
  } catch (error) {
    console.error('Error creating group:', error.message);
    res.status(400).json({ message: error.message });
  }
});


// Create channel route
app.post('/api/groups/:groupId/channels', async (req, res) => {
  const { groupId } = req.params;
  const { channelName } = req.body;

  try {
    const group = await getGroupById(groupsCollection, parseInt(groupId));

    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    await groupsCollection.updateOne(
      { id: parseInt(groupId) },
      { $push: { channels: channelName } }
    );

    res.json({ message: 'Channel added successfully', channels: [...group.channels, channelName] });
  } catch (error) {
    console.error('Error adding channel:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Remove channel route
app.delete('/api/groups/:groupId/channels/:channelName', async (req, res) => {
  const { groupId, channelName } = req.params;

  try {
    const group = await groupsCollection.findOne({ id: parseInt(groupId) });

    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const updatedChannels = group.channels.filter(channel => channel !== channelName);

    await groupsCollection.updateOne(
      { id: parseInt(groupId) },
      { $set: { channels: updatedChannels } }
    );

    res.json({ message: 'Channel removed successfully', channels: updatedChannels });
  } catch (error) {
    console.error('Error removing channel:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Remove group route
app.delete('/api/groups/:groupId', async (req, res) => {
  const { groupId } = req.params;

  try {
    const result = await removeGroup(groupsCollection, parseInt(groupId));
    res.json({ message: 'Group removed successfully', result });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// Leave group route
app.post('/api/leave-group', async (req, res) => {
  const { userId, groupId } = req.body;

  try {
    const user = await getUserById(usersCollection, userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const updatedUserGroups = user.groups.filter(id => id !== groupId);

    await updateUser(usersCollection, userId, { groups: updatedUserGroups });

    const group = await getGroupById(groupsCollection, groupId);
    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const updatedAdmins = group.administrators.includes(userId)
      ? group.administrators.filter(id => id !== userId)
      : group.administrators;

    await updateGroup(groupsCollection, groupId, { administrators: updatedAdmins });

    res.json({ message: 'Left group successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
});

// Remove user from group route
app.post('/api/groups/:groupId/remove-user', async(req, res) => {
  const groupId = parseInt(req.params.groupId);
  const { targetUserId } = req.body;

  try {
    const targetUser = await getUserById(usersCollection, targetUserId);
    if (!targetUser) {
      return res.status(404).json({ message: 'User not found' });
    }

    console.log(groupId);
    const group = await getGroupById(groupsCollection, groupId);
    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const updatedUserGroups = targetUser.groups.filter(id => id !== groupId);

    await updateUser(usersCollection, targetUserId, { groups: updatedUserGroups });

    const updatedAdmins = group.administrators.includes(targetUserId)
      ? group.administrators.filter(id => id !== targetUserId)
      : group.administrators;

    await updateGroup(groupsCollection, groupId, { administrators: updatedAdmins });

    res.json({ message: 'User removed from group successfully', groups: updatedUserGroups });
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
});

//Ban user route
app.post('/api/groups/:groupId/ban-user', async (req, res) => {
  const groupId = parseInt(req.params.groupId);
  const { channelName, userId } = req.body;

  try {
    const group = await getGroupById(groupsCollection, groupId);
    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    const user = await getUserById(usersCollection, userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const bannedUsers = group.bannedUsers || {};

    if (!bannedUsers[channelName]) {
      bannedUsers[channelName] = [];
    }

    bannedUsers[channelName].push(userId);

    await updateGroup(groupsCollection, groupId, { bannedUsers });

    res.json({ message: `User ${userId} banned from channel ${channelName}` });
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
});

//Promote group admin route
app.post('/api/users/:userId/promote-group-admin', async (req, res) => {
  const userId = parseInt(req.params.userId);
  const { groupId } = req.body;

  try {
    const user = await getUserById(usersCollection, userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const group = await getGroupById(groupsCollection, groupId);
    if (!group) {
      return res.status(404).json({ message: 'Group not found' });
    }

    if (!user.roles.includes('group administrator')) {
      await usersCollection.updateOne(
        { id: userId },
        { $addToSet: { roles: 'group administrator' } }
      );
    }

    if (!group.administrators.includes(userId)) {
      await groupsCollection.updateOne(
        { id: groupId },
        { $addToSet: { administrators: userId } }
      );
    }

    res.json({ message: 'User promoted to Group Admin successfully', group });
  } catch (error) {
    res.status(500).json({ message: 'Internal server error' });
  }
});



app.post('/api/users/:userId/promote-super-admin', async (req, res) => {
  const userId = parseInt(req.params.userId);

  try {
    const user = await getUserById(usersCollection, userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    if (user.roles.includes('super administrator')) {
      return res.status(400).json({ message: 'User is already a Super Admin' });
    }

    await usersCollection.updateOne(
      { id: userId },
      { $addToSet: { roles: 'super administrator' } }
    );

    res.json({ message: 'User promoted to Super Admin successfully' });
  } catch (error) {
    console.error('Error promoting super admin:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

//-----------------------------------------------------------------------------------------------------------//

/**************************************************************************
 *                                                                        *
 *            G R O U P J O I N R E Q U E S T S   R O U T E S             *
 *                                                                        *
 **************************************************************************/

app.post('/api/request-join', async (req, res) => {
  const { userId, groupId } = req.body;
  
  try {
    const existingRequest = await groupJoinRequestsCollection.findOne({ userId, groupId });
    if (existingRequest) {
      return res.status(400).json({ message: 'You have already requested to join this group' });
    }

    await groupJoinRequestsCollection.insertOne({ userId, groupId });

    res.json({ message: 'Request to join group sent successfully' });
  }  catch (error) {
    console.error('Error sending join request:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

app.post('/api/respond-request', async (req, res) => {
  const { userId, groupId, action } = req.body;

  if (action === 'accept') {
    await usersCollection.updateOne(
      { id: userId },
      { $addToSet: { groups: groupId } }
    );
  }

  await groupJoinRequestsCollection.deleteOne({ userId, groupId });

  res.json({ message: `Request has been ${action === 'accept' ? 'accepted' : 'rejected'}` });
});

app.get('/api/groupjoinrequests', async (req, res) => {
  try {
    // Fetch all join requests from the collection
    const joinRequests = await groupJoinRequestsCollection.find().toArray();
    res.json(joinRequests);
  } catch (error) {
    console.error('Error fetching group join requests:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

//-----------------------------------------------------------------------------------------------------------//

app.post('/api/upload-image', upload.single('image'), (req, res) => {
  if (!req.file) {
    return res.status(400).send('No file uploaded.');
  }

  // Send back the image URL
  const filePath = `http://localhost:3000/uploads/${req.file.filename}`;  // Serve from the root

  console.log('Uploaded image path:', filePath);

  res.json({ filePath });
});

//--------------------------------------------------------------------------------------------------------------//

let server = http.listen(3000, function () {
    let host = server.address().address;
    let port = server.address().port;
    console.log("My First Nodejs Server!");
    console.log("Server listening on: "+ host + " port: " + port);
});

module.exports = { app, server };