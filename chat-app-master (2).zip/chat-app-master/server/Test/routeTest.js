const { MongoClient } = require('mongodb');
const chai = require('chai');
const chaiHttp = require('chai-http');
const { app, server } = require('../server.js');

chai.should();
chai.use(chaiHttp);

const url = 'mongodb://localhost:27017';
const dbName = 'chat-app';
let client;
let db;
let usersCollection;

before(async () => {
  client = await MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true });
  db = client.db(dbName);
  usersCollection = db.collection('users');
  groupsCollection = db.collection('groups');
  groupJoinRequestsCollection = db.collection('groupJoinRequests');
});

after(async () => {
  await client.close();
});

describe('GET /api/users', () => {
    it('should return all users', (done) => {
      chai.request(app)
        .get('/api/users')
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('array');
          done();
        });
    });
  
    it('should return a non-empty array of users', (done) => {
      chai.request(app)
        .get('/api/users')
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('array');
          res.body.length.should.be.above(0);
          done();
        });
    });
  });

  describe('POST /api/signup', () => {
  
    // Clean up test data after each test
    afterEach(async () => {
      await usersCollection.deleteOne({ email: 'test_user@example.com' });
      await usersCollection.deleteOne({ email: 'incomplete_user@example.com' });
    });
  
    it('should sign up a new user successfully', (done) => {
      const newUser = {
        username: 'test_user',
        email: 'test_user@example.com',
        password: '123456',
        profileImage: 'anais.jpg'
      };
      chai.request(app)
        .post('/api/signup')
        .send(newUser)
        .end((err, res) => {
          res.should.have.status(200);  // Check for success status
          res.body.should.be.a('object');
          res.body.should.have.property('username').eql('test_user');
          done();
        });
    });
  
    it('should return a 400 error when required fields are missing', (done) => {
      const incompleteUser = {
        username: 'incomplete_user',
        email: 'incomplete_user@example.com'
      };
      chai.request(app)
        .post('/api/signup')
        .send(incompleteUser)
        .end((err, res) => {
          res.should.have.status(400);  // Check for error status
          res.body.should.have.property('message').eql('All fields are required');
          done();
        });
    });
  });
  
  describe('DELETE /api/users/:userId', () => {
  
    let userId;

    // Create a user before running each test
    beforeEach(async () => {
      const newUser = {
        username: 'test_user_delete',
        email: 'delete_user@example.com',
        password: '123456',
        profileImage: 'delete_image.jpg',
        id: Date.now()
      };
      const result = await usersCollection.insertOne(newUser);
      const insertedUser = await usersCollection.findOne({ _id: result.insertedId });

      userId = insertedUser.id;
      console.log('Inserted userId:', userId);  
    });
  
    afterEach(async () => {
      await usersCollection.deleteOne({ email: 'delete_user@example.com' });
    });
  
    it('should delete a user successfully', (done) => {
      chai.request(app)
        .delete(`/api/users/${userId}`)
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.have.property('message').eql('User deleted successfully');
          done();
        });
    });
  
    it('should not delete a non-existing user', (done) => {
        userId = 0
        chai.request(app)
        .delete('/api/users/${userId}')
        .end((err, res) => {
          res.should.have.status(400);
          res.body.should.have.property('message').eql('User not found');
          done();
        });
    });
  });

  describe('GET /api/groups', () => {
    it('should return all groups', (done) => {
      chai.request(app)
        .get('/api/groups')
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('array');
          done();
        });
    });
  
    it('should return a non-empty array of groups', (done) => {
      chai.request(app)
        .get('/api/groups')
        .end((err, res) => {
          res.should.have.status(200);
          res.body.should.be.a('array');
          res.body.length.should.be.above(0);
          done();
        });
    });
  });

  describe('POST /api/groups', function () {
    this.timeout(5000); 
  
    afterEach(async () => {
      await groupsCollection.deleteOne({ name: 'test_group' });
    });
  
    it('should create a new group and associate it with the userId 1', (done) => {
      const newGroupData = {
        groupName: 'test_group',
        userId: 1
      };
  
      chai.request(app)
        .post('/api/groups')
        .send(newGroupData)
        .end((err, res) => {
          if (err) return done(err);
          res.should.have.status(200);  // Expecting success response
          res.body.should.have.property('name').eql('test_group');  // Check the group name
          res.body.should.have.property('id');  // Ensure the group has an ID
          res.body.should.have.property('administrators').that.includes(1);  // Check that userId 1 is an admin
          res.body.should.have.property('channels').that.is.an('array');  // Channels should be an empty array
          done();  // Ensure done() is called after async operations complete
        });
    });
  
    it('should return a 400 error when group creation fails', (done) => {
      const invalidGroupData = {
        groupName: '',  // Invalid group name (empty)
        userId: 1  // Using hardcoded user ID 1
      };
  
      chai.request(app)
        .post('/api/groups')
        .send(invalidGroupData)
        .end((err, res) => {
          if (err) return done(err);  // Handle any errors
          res.should.have.status(400);  // Expecting error status
          res.body.should.have.property('message');
          done();
        });
    });
  });

  describe('POST /api/groups/:groupId/channels', function () {
    this.timeout(5000);  // Increase timeout
  
    // Clean up the test data after each test
    afterEach(async () => {
      await groupsCollection.updateOne(
        { id: 1 }, 
        { $pull: { channels: 'test_channel' } }  // Remove the test channel if it exists
      );
    });
  
    it('should add a new channel to the group with groupId 1', (done) => {
      const newChannelData = {
        channelName: 'test_channel'  // The name of the new channel
      };
  
      chai.request(app)
        .post('/api/groups/1/channels')  // Using hardcoded groupId 1
        .send(newChannelData)
        .end((err, res) => {
          if (err) return done(err);
          res.should.have.status(200);  // Expecting success response
          res.body.should.have.property('message').eql('Channel added successfully');  // Check success message
          res.body.should.have.property('channels').that.includes('test_channel');  // Check if the channel was added
          done();
        });
    });
  
    it('should return a 500 error when group with groupId does not exist', (done) => {
        const newChannelData = {
          channelName: 'test_channel'
        };
      
        chai.request(app)
          .post('/api/groups/999/channels')  // Using an invalid groupId (999)
          .send(newChannelData)
          .end((err, res) => {
            if (err) return done(err);
            res.should.have.status(500);  // Expecting 500 Internal server error
            res.body.should.have.property('message').eql('Internal server error');  // Check for error message
            done();
          });
      });
      
  });

  describe('DELETE /api/groups/:groupId', function () {
    this.timeout(5000);
  
    let testGroupId;
  
    beforeEach(async () => {
      const newGroup = {
        id: Date.now(),
        name: 'test_group',
        administrators: [1],
        channels: []
      };
      await groupsCollection.insertOne(newGroup);
      testGroupId = newGroup.id;
    });
  
    afterEach(async () => {
      await groupsCollection.deleteOne({ id: testGroupId });
    });
  
    it('should remove the group with the specified groupId', (done) => {
      chai.request(app)
        .delete(`/api/groups/${testGroupId}`)
        .end((err, res) => {
          if (err) return done(err);
          res.should.have.status(200);
          res.body.should.have.property('message').eql('Group removed successfully');
          done();
        });
    });
  
    it('should return a 400 error when group does not exist', (done) => {
      chai.request(app)
        .delete('/api/groups/999999')
        .end((err, res) => {
          if (err) return done(err);
          res.should.have.status(400);
          res.body.should.have.property('message');
          done();
        });
    });
  });

  describe('POST /api/groups/:groupId/remove-user', function () {
    this.timeout(5000);
  
    let testGroupId = 99;
    let testUserId = 99;
  
    beforeEach(async () => {
      const testUser = {
        id: testUserId,
        username: 'test_user',
        email: 'test_user@example.com',
        password: '123456',
        groups: [testGroupId]
      };
  
      const testGroup = {
        id: testGroupId,
        name: 'test_group',
        administrators: [testUserId],
        channels: []
      };
  
      await usersCollection.insertOne(testUser);
      await groupsCollection.insertOne(testGroup);
    });
  
    afterEach(async () => {
      await usersCollection.deleteOne({ id: testUserId });
      await groupsCollection.deleteOne({ id: testGroupId });
    });
  
    it('should remove a user from the group successfully', (done) => {
      const removeUserData = {
        targetUserId: testUserId
      };
  
      chai.request(app)
        .post(`/api/groups/${testGroupId}/remove-user`)
        .send(removeUserData)
        .end((err, res) => {
          if (err) return done(err);
          res.should.have.status(200);
          res.body.should.have.property('message').eql('User removed from group successfully');
          done();
        });
    });
  
    it('should return a 500 error when the user does not exist', (done) => {
      const removeUserData = {
        targetUserId: 999
      };
  
      chai.request(app)
        .post(`/api/groups/${testGroupId}/remove-user`)
        .send(removeUserData)
        .end((err, res) => {
          if (err) return done(err);
          res.should.have.status(500);
          res.body.should.have.property('message');
          done();
        });
    });
  });
  
  describe('POST /api/groups/:groupId/ban-user', function () {
    this.timeout(10000);  // Increase timeout to account for the delay
  
    let testGroupId = 99;
    let testUserId = 99;
  
    beforeEach(async () => {
      const testUser = {
        id: testUserId,
        username: 'test_user',
        email: 'test_user@example.com',
        password: '123456',
        groups: [testGroupId]
      };
  
      const testGroup = {
        id: testGroupId,
        name: 'test_group',
        administrators: [testUserId],
        channels: ['General Discussion'],
        bannedUsers: {}
      };
  
      await usersCollection.insertOne(testUser);
      await groupsCollection.insertOne(testGroup);
  
      // Wait for 1 second before running the tests
      await new Promise(resolve => setTimeout(resolve, 1000));
    });
  
    afterEach(async () => {
      await usersCollection.deleteOne({ id: testUserId });
      await groupsCollection.deleteOne({ id: testGroupId });
    });
  
    it('should ban a user from a specific channel in the group successfully', (done) => {
      const banUserData = {
        channelName: 'General Discussion',
        userId: testUserId
      };
  
      chai.request(app)
        .post(`/api/groups/${testGroupId}/ban-user`)
        .send(banUserData)
        .end((err, res) => {
          if (err) return done(err);
          res.should.have.status(200);
          res.body.should.have.property('message').eql(`User ${testUserId} banned from channel General Discussion`);
          done();
        });
    });
  
    it('should return a 500 error when the user does not exist', (done) => {
      const banUserData = {
        channelName: 'General Discussion',
        userId: 999  // Non-existent user
      };
  
      chai.request(app)
        .post(`/api/groups/${testGroupId}/ban-user`)
        .send(banUserData)
        .end((err, res) => {
          if (err) return done(err);
          res.should.have.status(500);
          done();
        });
    });
  
    it('should return a 500 error when the group does not exist', (done) => {
      const banUserData = {
        channelName: 'General Discussion',
        userId: testUserId
      };
  
      chai.request(app)
        .post(`/api/groups/999/ban-user`)
        .send(banUserData)
        .end((err, res) => {
          if (err) return done(err);
          res.should.have.status(500);
          done();
        });
    });
  });

  app.post('/api/users/:userId/promote-group-admin', async (req, res) => {
    const userId = parseInt(req.params.userId);
    const { groupId } = req.body;
  
    try {
      const user = await getUserById(usersCollection, userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      const group = await getGroupById(groupsCollection, groupId);
      if (!group) {
        return res.status(404).json({ message: 'Group not found' });
      }
  
      if (!user.roles.includes('group administrator')) {
        await usersCollection.updateOne(
          { id: userId },
          { $addToSet: { roles: 'group administrator' } }
        );
      }
  
      if (!group.administrators.includes(userId)) {
        await groupsCollection.updateOne(
          { id: groupId },
          { $addToSet: { administrators: userId } }
        );
      }
  
      res.json({ message: 'User promoted to Group Admin successfully', group });
    } catch (error) {
      console.error('Error promoting group admin:', error);  // Add this line
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  describe('POST /api/users/:userId/promote-super-admin', function () {
    this.timeout(5000);
  
    let testUserId = 99;
  
    beforeEach(async () => {
      const testUser = {
        id: testUserId,
        username: 'test_user',
        email: 'test_user@example.com',
        password: '123456',
        roles: ['chat user'], // Default role
      };
  
      await usersCollection.insertOne(testUser);
    });
  
    afterEach(async () => {
      await usersCollection.deleteOne({ id: testUserId });
    });
  
    it('should promote a user to super administrator successfully', (done) => {
      chai.request(app)
        .post(`/api/users/${testUserId}/promote-super-admin`)
        .end(async (err, res) => {
          if (err) return done(err);
          res.should.have.status(200);
          res.body.should.have.property('message').eql('User promoted to Super Admin successfully');
  
          // Fetch the updated user to check if they have the super administrator role
          const updatedUser = await usersCollection.findOne({ id: testUserId });
          updatedUser.roles.should.include('super administrator');  // Check if the user has the role
  
          done();
        });
    });
  
    it('should return a 400 error if the user is already a Super Admin', (done) => {
      // First, promote the user to Super Admin
      chai.request(app)
        .post(`/api/users/${testUserId}/promote-super-admin`)
        .end((err, res) => {
          if (err) return done(err);
  
          // Then, try promoting again and expect a 400 error
          chai.request(app)
            .post(`/api/users/${testUserId}/promote-super-admin`)
            .end((err, res) => {
              if (err) return done(err);
              res.should.have.status(400);
              res.body.should.have.property('message').eql('User is already a Super Admin');
              done();
            });
        });
    });
  
    it('should return a 404 error if the user does not exist', (done) => {
      chai.request(app)
        .post(`/api/users/999/promote-super-admin`)  // Non-existent user
        .end((err, res) => {
          if (err) return done(err);
          res.should.have.status(500);
          res.body.should.have.property('message');
          done();
        });
    });
  });

  describe('POST /api/request-join', function () {
    this.timeout(5000);
  
    let testUserId = 99;
    let testGroupId = 99;
  
    beforeEach(async () => {
      const testUser = {
        id: testUserId,
        username: 'test_user',
        email: 'test_user@example.com',
        password: '123456',
        roles: ['chat user']
      };
  
      const testGroup = {
        id: testGroupId,
        name: 'test_group',
        administrators: [],
        channels: ['General Discussion']
      };
  
      await usersCollection.insertOne(testUser);
      await groupsCollection.insertOne(testGroup);
    });
  
    afterEach(async () => {
      await usersCollection.deleteOne({ id: testUserId });
      await groupsCollection.deleteOne({ id: testGroupId });
      await groupJoinRequestsCollection.deleteMany({ userId: testUserId, groupId: testGroupId });
    });
  
    it('should send a join request successfully', (done) => {
      const joinRequestData = {
        userId: testUserId,
        groupId: testGroupId
      };
  
      chai.request(app)
        .post('/api/request-join')
        .send(joinRequestData)
        .end((err, res) => {
          if (err) return done(err);
          res.should.have.status(200);
          res.body.should.have.property('message').eql('Request to join group sent successfully');
  
          // Verify that the request has been saved in the collection
          groupJoinRequestsCollection.findOne({ userId: testUserId, groupId: testGroupId })
            .then(request => {
              request.should.not.be.null;
              done();
            })
            .catch(done);
        });
    });
  
    it('should return a 400 error if the user has already requested to join', (done) => {
      // First, insert the join request
      groupJoinRequestsCollection.insertOne({ userId: testUserId, groupId: testGroupId })
        .then(() => {
          // Now, try to insert the same request again
          const joinRequestData = {
            userId: testUserId,
            groupId: testGroupId
          };
  
          chai.request(app)
            .post('/api/request-join')
            .send(joinRequestData)
            .end((err, res) => {
              if (err) return done(err);
              res.should.have.status(400);
              res.body.should.have.property('message').eql('You have already requested to join this group');
              done();
            });
        })
        .catch(done);
    });
  });

  