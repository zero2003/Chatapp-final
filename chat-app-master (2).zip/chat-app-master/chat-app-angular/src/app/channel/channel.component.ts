import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { SocketService } from '../socket.service';

@Component({
  selector: 'app-channel',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './channel.component.html',
  styleUrls: ['./channel.component.css']
})
export class ChannelComponent implements OnInit, OnDestroy {
  channelName: string = '';
  user: any = null;
  profileImage: any = null;
  newMessage: string = '';
  selectedFile: File | null = null;
  messages: { user: string, profileImage: string, text: string, imagePath?: string }[] = [];  // Array for messages

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private http: HttpClient,
    private socketService: SocketService  // Inject the SocketService
  ) {}

  ngOnInit(): void {
    // Get the channel name from route params
    this.route.params.subscribe(params => {
      this.channelName = params['channelName'];
    });

    // Check if user data is available in sessionStorage
    const storedUser = sessionStorage.getItem('user');
    if (storedUser) {
      this.user = JSON.parse(storedUser);
      console.log('User Data:', this.user);

      // Join the channel using Socket.IO
      this.socketService.joinChannel(this.channelName, this.user.username);

      // Load previous messages when joining the channel
      this.socketService.onLoadPreviousMessages().subscribe((previousMessages) => {
        this.messages = [...previousMessages, ...this.messages];
      })

      // Subscribe to receive messages
      this.socketService.onReceiveMessage().subscribe((message) => {
        this.messages.push({ user: message.user, text: message.message, profileImage: message.profileImage, imagePath: message.imagePath });
      });


      this.socketService.onUserJoined().subscribe((data) => {
        this.messages.push({ user: 'SYSTEM', text: `${data.user} has joined the channel.`, profileImage: '' });
      });
  
      // Listen for userLeft event and display a message
      this.socketService.onUserLeft().subscribe((data) => {
        this.messages.push({ user: 'SYSTEM', text: `${data.user} has left the channel.`, profileImage: '' });
      });
    } else {
      // If no user data is found, redirect to login page
      console.error('No user data found, redirecting to login');
      this.router.navigate(['/login']);
    }
  }

  onFileSelected(event: any): void {
    this.selectedFile = event.target.files[0];  // Store the selected file
  }

  // Send a message using Socket.IO (include profileImage)
  sendMessage(): void {
    if (this.newMessage.trim() !== '') {
      this.socketService.sendMessage(this.channelName, { 
        user: this.user.username,
        profileImage: this.user.profileImage,
        text: this.newMessage
      });

      // Clear the input field after sending
      this.newMessage = '';
    } else if (this.selectedFile) {
      // If it's an image message, upload the image first
      const formData = new FormData();
      formData.append('image', this.selectedFile);

      // Upload the image to the server
      this.http.post<{ filePath: string }>('http://localhost:3000/api/upload-image', formData)
        .subscribe(response => {
          // Send the image message with the image path
          this.socketService.sendMessage(this.channelName, {
            user: this.user.username,
            text: '',
            profileImage: this.user.profileImage,
            imagePath: response.filePath  // Include the path of the uploaded image
          });

          console.log('Uploaded image path:', response.filePath);

          // Clear the selected file after sending
          this.selectedFile = null;
        }, error => {
          console.error('Image upload failed:', error);
        });
    }
  }

  // Leave the channel when the component is destroyed
  ngOnDestroy(): void {
    if (this.user && this.user.username) {
      this.socketService.leaveChannel(this.channelName, this.user.username);
    }
  }  
}
