import { Injectable } from '@angular/core';
import { io, Socket } from 'socket.io-client';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class SocketService {
  private socket: Socket;

  constructor() {
    this.socket = io('http://localhost:3000');  // Replace with your server URL if needed
  }

  joinChannel(channelName: string, username: string): void {
    this.socket.emit('joinChannel', { channelName, username });
  }

  leaveChannel(channelName: string, username: string): void {
    this.socket.emit('leaveChannel', { channelName, username });
  }


  sendMessage(channelName: string, message: { user: string; profileImage: string; text: string, imagePath?: string }): void {
    this.socket.emit('sendMessage', { channelName, message });
  }

  // Listen for messages in a channel
  onReceiveMessage(): Observable<{ user: string, profileImage: string, message: string, imagePath?: string }> {
    return new Observable((observer) => {
      this.socket.on('receiveMessage', (data) => {
        observer.next(data);
      });
    });
  }

    // Listen for user joining a channel
  onUserJoined(): Observable<{ user: string, message: string }> {
    return new Observable((observer) => {
      this.socket.on('userJoined', (data) => {
        observer.next(data);
      });
    });
  }

  // Listen for user leaving a channel
  onUserLeft(): Observable<{ user: string, message: string }> {
    return new Observable((observer) => {
      this.socket.on('userLeft', (data) => {
        observer.next(data);
      });
    });
  }

  // Listen for previous messages when joining a channel
  onLoadPreviousMessages(): Observable<{ user: string, profileImage: string, text: string, imagePath?: string }[]> {
    return new Observable((observer) => {
      this.socket.on('loadPreviousMessages', (data) => {
        observer.next(data);
      });
    });
  }
  
  // Handle socket disconnection
  disconnect(): void {
    if (this.socket) {
      this.socket.disconnect();
    }
  }
}
