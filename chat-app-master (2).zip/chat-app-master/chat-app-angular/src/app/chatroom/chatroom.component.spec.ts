import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ChatroomComponent } from './chatroom.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { of } from 'rxjs';

describe('ChatroomComponent', () => {
  let component: ChatroomComponent;
  let fixture: ComponentFixture<ChatroomComponent>;
  let httpTestingController: HttpTestingController;

  const mockUser = {
    id: 1,
    username: 'test_user',
    roles: ['group administrator'],  // Mocking 'group administrator', not 'super administrator'
    groups: [99]
  };

  const mockGroups = [
    { id: 1, name: 'Group 1', administrators: [1], channels: ['General'], bannedUsers: {} },
    { id: 2, name: 'Group 2', administrators: [1, 2], channels: ['Off-topic'], bannedUsers: {} }
  ];

  const mockUsers = [
    { id: 1, username: 'test_user', roles: ['group administrator'], groups: [99] },
    { id: 2, username: 'other_user', roles: ['user'], groups: [] }
  ];

  beforeEach(async () => {

    spyOn(sessionStorage, 'getItem').and.callFake((key: string) => {
      if (key === 'user') {
        return JSON.stringify(mockUser);  // Return the mock user as JSON
      }
      return null;
    });

    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,  
        RouterTestingModule,      
        FormsModule,             
        CommonModule,             
        ChatroomComponent        
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ChatroomComponent);
    component = fixture.componentInstance;
    httpTestingController = TestBed.inject(HttpTestingController);

    component.ngOnInit();
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
    TestBed.resetTestingModule();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load the user from sessionStorage', () => {
  
    // Mock the HTTP request to fetch users
    const httpSpy = spyOn(component['http'], 'get').and.returnValue(of(mockUsers));
    
    // Trigger ngOnInit manually since sessionStorage is mocked after component initialization
    component.ngOnInit();
  
    // Simulate fetching users
    expect(component.users.length).toBeGreaterThan(0); // Ensure users array is populated
    expect(component.userRoles).toBeDefined(); // Ensure userRoles is defined
    expect(component.userRoles.length).toBeGreaterThan(0);  // Ensure roles are set
    expect(component.userId).toBe(1);  // Ensure userId is loaded correctly
  
    const user = component.users.find(u => u.id === component.userId);
    expect(user?.username).toBe('test_user'); // Ensure username is 'test_user'
    expect(user?.roles).toContain('group administrator'); // Ensure the user has 'group administrator' role
  });

  it('should handle super admin role', () => {
    // Test the isSuperAdmin function behavior
    expect(component.isSuperAdmin()).toBeFalse(); // No 'super administrator' in mockUser roles
  });

  it('should fetch groups on initialization', () => {

    // Use of() to return an observable for the mock data
    const httpSpy = spyOn(component['http'], 'get').and.returnValue(of(mockGroups));

    // Trigger ngOnInit manually to call fetchGroups
    component.ngOnInit();

    // Check if the HTTP request was made
    expect(httpSpy).toHaveBeenCalledWith('http://localhost:3000/api/groups');

    // Check if the groups array was populated
    expect(component.groups.length).toBe(2);
    expect(component.groups[0].name).toBe('Group 1');
    expect(component.groups[1].name).toBe('Group 2');
  });
});
