import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgIf, NgFor, NgClass } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

interface Group {
  id: number;
  name: string;
  administrators: number[];
  channels: string[];
  bannedUsers: { [channelName: string]: number[] };
}

interface User {
  id: number;
  username: string;
  roles: string[];
  groups: number[];
}

interface GroupJoinRequest {
  userId: number;
  groupId: number;
}

@Component({
  selector: 'app-chatroom',
  standalone: true,
  imports: [NgFor, NgIf, NgClass, FormsModule, RouterModule],
  templateUrl: './chatroom.component.html',
  styleUrls: ['./chatroom.component.css']
})
export class ChatroomComponent implements OnInit {

  groups: Group[] = [];
  users: User[] = [];
  userGroups: number[] = [];
  userRoles: string[] = [];
  userId: number = 0;
  groupJoinRequests: GroupJoinRequest[] = [];
  requestedGroups: number[] = [];
  newGroupName: string = '';
  newChannelName: string = '';
  banUsername: string = '';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    // Load the current user data from sessionStorage
    const user = JSON.parse(sessionStorage.getItem('user') || '{}');
    this.userRoles = user.roles;
    this.userId = user.id;
    this.userGroups = user.groups;

    this.fetchGroups();
    this.fetchUsers();
    this.fetchGroupJoinRequests();
  }

  fetchGroups() {
    this.http.get<Group[]>('http://localhost:3000/api/groups')
      .subscribe(groups => {
        this.groups = groups;
      });
  }

  fetchUsers() {
    this.http.get<User[]>('http://localhost:3000/api/users')
      .subscribe(users => {
        this.users = users;
      });
  }

  fetchGroupJoinRequests() {
    this.http.get<GroupJoinRequest[]>('http://localhost:3000/api/groupjoinrequests')
      .subscribe(requests => {
        this.groupJoinRequests = requests;
      });
  }

  isSuperAdmin(): boolean {
    return this.userRoles.includes('super administrator');
  }

  canCreateGroup(): boolean {
    return this.userRoles.includes('group administrator');
  }

  getGroupMembers(groupId: number): User[] {
    return this.users.filter(user => user.groups.includes(groupId));
  }

  // New function to get a user by their ID
  getUserById(userId: number): User | undefined {
    return this.users.find(user => user.id === userId);
  }

  requestToJoin(groupId: number) {
    this.http.post('http://localhost:3000/api/request-join', { userId: this.userId, groupId }).subscribe(response => {
      console.log('Request sent:', response);
      this.requestedGroups.push(groupId);
    }, error => {
      console.error('Error:', error);
    });
  }

  getJoinRequestsForGroup(groupId: number): GroupJoinRequest[] {
    return this.groupJoinRequests.filter(request => request.groupId === groupId);
  }

  handleJoinRequest(userId: number, groupId: number, action: 'accept' | 'reject') {
    this.http.post('http://localhost:3000/api/respond-request', { userId, groupId, action }).subscribe(response => {
      console.log(`Request ${action}ed:`, response);
      this.fetchUsers(); // Refresh users after accepting/rejecting
      this.fetchGroupJoinRequests(); // Refresh join requests after accepting/rejecting
    }, error => {
      console.error('Error:', error);
    });
  }

  leaveGroup(groupId: number) {
    this.http.post('http://localhost:3000/api/leave-group', { userId: this.userId, groupId }).subscribe(response => {
      console.log('Left group:', response);
      // Remove the group from the user's local group list and refresh the display
      this.http.get<User[]>('http://localhost:3000/api/users').subscribe(users => {
        this.users = users; // Update the users array
        const currentUser = this.users.find(user => user.id === this.userId);
        if (currentUser) {
          sessionStorage.setItem('user', JSON.stringify(currentUser));
          // Update the local variables with the latest session data
          this.userRoles = currentUser.roles;
          this.userGroups = currentUser.groups;
          this.userId = currentUser.id;
        }
      });
      this.http.get<Group[]>('http://localhost:3000/api/groups')
      .subscribe(groups => {
        this.groups = groups;
      });
    }, error => {
      console.error('Error:', error);
    });
    
  }

  createGroup() {
    if (!this.newGroupName.trim()) {
      return;
    }
  
    this.http.post<Group>('http://localhost:3000/api/groups', { groupName: this.newGroupName, userId: this.userId })
      .subscribe(newGroup => {
  
        this.fetchGroups(); // Refresh the list of groups
  
        // Call fetchUsers and handle the session update in its callback
        this.http.get<User[]>('http://localhost:3000/api/users').subscribe(users => {
          this.users = users; // Update the users array
          const currentUser = this.users.find(user => user.id === this.userId);
          if (currentUser) {
            sessionStorage.setItem('user', JSON.stringify(currentUser));
            // Update the local variables with the latest session data
            this.userRoles = currentUser.roles;
            this.userGroups = currentUser.groups;
            this.userId = currentUser.id;
          }
  
          this.newGroupName = ''; // Clear the input field
        });
  
      }, error => {
        console.error('Error:', error);
      });
  }
  

  createChannel(groupId: number) {
    if (!this.newChannelName.trim()) {
      return;
    }
  
    this.http.post<{ message: string; channels: string[] }>(`http://localhost:3000/api/groups/${groupId}/channels`, { userId: this.userId, channelName: this.newChannelName })
      .subscribe(response => {
        const group = this.groups.find(g => g.id === groupId);
        if (group) {
          group.channels = response.channels; // Update the channels list for this group
        }
        this.newChannelName = ''; // Clear the input field
      }, error => {
        console.error('Error:', error);
      });
  }

  removeChannel(groupId: number, channelName: string) {
    this.http.delete(`http://localhost:3000/api/groups/${groupId}/channels/${channelName}`, { body: { userId: this.userId } })
      .subscribe(response => {
        console.log('Channel removed:', response);
        this.fetchGroups(); // Refresh groups to update UI
      }, error => {
        console.error('Error:', error);
      });
  }

  removeUserFromGroup(groupId: number, targetUserId: number) {
    this.http.post(`http://localhost:3000/api/groups/${groupId}/remove-user`, { targetUserId })
      .subscribe(response => {
        console.log('User removed from group:', response);
        this.fetchGroups();
        this.fetchUsers();
      }, error => {
        console.error('Error:', error);
      });
  }

  removeGroup(groupId: number) {
    this.http.delete(`http://localhost:3000/api/groups/${groupId}`, { body: { userId: this.userId } })
      .subscribe(response => {
        console.log('Group removed:', response);
        this.fetchGroups(); // Refresh groups to update UI
      }, error => {
        console.error('Error:', error);
      });
  }
  
  isAdminOfGroup(groupId: number): boolean {
    const group = this.groups.find(g => g.id === groupId);
    return group ? group.administrators.includes(this.userId) : false;
  }

  banUserFromChannel(groupId: number, channelName: string, banUsername: string) {
    // Find the user by their username
    const userToBan = this.users.find(user => user.username === banUsername);
  
    if (!userToBan) {
      console.error('User not found:', banUsername);
      return;
    }
  
    // Extract the userId
    const userId = userToBan.id;
  
    // Proceed with the ban
    this.http.post(`http://localhost:3000/api/groups/${groupId}/ban-user`, { channelName, userId })
      .subscribe(response => {
        console.log('User banned:', response);
        this.fetchGroups(); // Refresh groups after banning the user
        this.banUsername = '';
      }, error => {
        console.error('Error while banning user from channel:', error);
      });
  }

  isUserBannedFromChannel(groupId: number, channelName: string): boolean {
    const group = this.groups.find(g => g.id === groupId);
    if (!group || !group.bannedUsers || !group.bannedUsers[channelName]) {
      return false;
    }
    return group.bannedUsers[channelName].includes(this.userId);
  }
  
  
}
