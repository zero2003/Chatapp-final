import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [NgIf, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(private router: Router, private http: HttpClient) {}

  onLogin() {
    const loginData = { email: this.email, password: this.password };
    console.log('Login Data:', loginData);

    this.http.post<any>('http://localhost:3000/api/auth', loginData)
      .subscribe(
        response => {
          if (response.valid) {
            console.log('Server Response:', response);
            // Store user data in session storage (without password)
            sessionStorage.setItem('user', JSON.stringify(response));
            // Navigate to the account page
            this.router.navigate(['/account']);
          } else {
            this.errorMessage = 'Invalid email or password';
          }
        },
        error => {
          console.error('HTTP Error:', error);
          this.errorMessage = 'Invalid email or password';
        }
      );
    }

}
