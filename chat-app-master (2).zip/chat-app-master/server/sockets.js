// sockets.js
var io = require('socket.io');
const { MongoClient } = require('mongodb');

let db, messagesCollection;

async function connectDB() {
  const uri = "mongodb://localhost:27017";
  const client = new MongoClient(uri);

  try {
    await client.connect();
    db = client.db('chat-app');
    messagesCollection = db.collection('messages');
    console.log('Connected to MongoDB - Messages collection ready');
  } catch (error) {
    console.error('Failed to connect to MongoDB:', error);
    process.exit(1);
  }
}

connectDB();

function initSocket(http) {
  const socketServer = io(http, {
    cors: {
      origin: "http://localhost:4200",  // Replace this with your Angular app's URL
      methods: ["GET", "POST"],         // Allow GET and POST methods
      credentials: true                 // Allow credentials (e.g., cookies, authorization headers)
    }
  });

  // Handle socket connections
  socketServer.on('connection', (socket) => {
    console.log('A user connected: ', socket.id);

    // Listen for joining a channel
    socket.on('joinChannel', async({ channelName, username }) => {
      socket.join(channelName);
      console.log(`${username} (socket ID: ${socket.id}) joined channel ${channelName}`);

      // Optionally, load previous messages from this channel
      const previousMessages = await messagesCollection.find({ channelName }).toArray();
      socket.emit('loadPreviousMessages', previousMessages);

      // Notify others in the channel that a user joined, using the username
      socketServer.to(channelName).emit('userJoined', {
        user: username,
        message: `${username} has joined the channel.`
      });
    });

    // Listen for leaving a channel
    socket.on('leaveChannel', ({ channelName, username }) => {
      socket.leave(channelName);
      console.log(`${username} (socket ID: ${socket.id}) left channel ${channelName}`);

      // Notify others in the channel that a user left, using the username
      socketServer.to(channelName).emit('userLeft', {
        user: username,
        message: `${username} has left the channel.`
      });
    });

    // Listen for sending a message
    socket.on('sendMessage', async({ channelName, message }) => {
        console.log(`${message.user} sent message to ${channelName}: ${message.text}`);
  
        // Emit the message to ALL clients in the room (including the sender)
        socketServer.to(channelName).emit('receiveMessage', {
          user: message.user,
          profileImage: message.profileImage,
          message: message.text,
          imagePath: message.imagePath || null
        });

        try {
          const newMessage = {
            user: message.user,
            profileImage: message.profileImage,
            text: message.text,
            imagePath: message.imagePath || null,
            channelName: channelName,
            timestamp: new Date()
          };
          await messagesCollection.insertOne(newMessage);
          console.log('Message saved to MongoDB');
        } catch (error) {
          console.error('Error saving message to MongoDB:', error);
        }
      });

    // Disconnect event
    socket.on('disconnect', () => {
      console.log('User disconnected: ', socket.id);
    });
  });

  return socketServer;
}

module.exports = initSocket;
