async function updateGroup(groupsCollection, groupId, updates) {
    const result = await groupsCollection.updateOne(
      { id: groupId },
      { $set: updates }
    );
  
    if (result.matchedCount === 0) {
      throw new Error('Group not found');
    }
  
    return result;
  }
  
  module.exports = updateGroup;
  