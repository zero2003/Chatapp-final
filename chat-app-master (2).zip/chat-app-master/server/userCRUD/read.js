// read.js
async function getAllUsers(usersCollection) {
    const users = await usersCollection.find().toArray();
    return users;
  }
  
async function getUserById(usersCollection, userId) {
    const user = await usersCollection.findOne({ id: userId });
    if (!user) {
      throw new Error('User not found');
    }
    return user;
}
  
module.exports = { getAllUsers, getUserById };
  