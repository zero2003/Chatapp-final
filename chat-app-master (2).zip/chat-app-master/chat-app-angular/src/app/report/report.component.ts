import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { NgIf, NgFor, NgClass } from '@angular/common';
import { RouterModule } from '@angular/router';

interface Group {
  id: number;
  name: string;
  administrators: number[];
  channels: string[];
  bannedUsers: { [channelName: string]: number[] };
}

interface User {
  id: number;
  username: string;
  roles: string[];
}

@Component({
  selector: 'app-report',
  standalone: true,
  imports: [NgFor, NgIf, NgClass, RouterModule],
  templateUrl: './report.component.html',
  styleUrl: './report.component.css'
})
export class ReportComponent implements OnInit {
  groups: Group[] = [];
  users: User[] = [];
  userRoles: string[] = [];

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.fetchGroups();
    this.fetchUsers(); // Fetch users to match IDs to usernames
  }

  fetchGroups() {
    this.http.get<Group[]>('http://localhost:3000/api/groups')
      .subscribe(groups => {
        this.groups = groups;
      });
  }

  fetchUsers() {
    this.http.get<User[]>('http://localhost:3000/api/users')
      .subscribe(users => {
        this.users = users;
      });
  }

  getUsernameById(userId: number): string {
    const user = this.users.find(u => u.id === userId);
    return user ? user.username : 'Unknown User';
  }
}
